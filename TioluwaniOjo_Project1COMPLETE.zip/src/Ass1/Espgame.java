package Ass1;

import java.util.Random;
import java.util.Scanner;

/*
 * Class: CMSC203
 * Instructor:
 * Description: ESP guessing game without arrays or extra methods.
 * Due: MM/DD/YY
 * Platform/compiler: Java (any standard JDK)
 * I pledge that I have completed the programming assignment independently.
 * Print your Name here: ______________________
 */
public class Espgame {
    // constants
    private static final String TITLE = "CMSC203 Assignment1: Test your ESP skills!";
    private static final int TOTAL_ROUNDS = 11;

    // color constants (7 colors, no arrays)
    private static final String RED    = "Red";
    private static final String GREEN  = "Green";
    private static final String BLUE   = "Blue";
    private static final String ORANGE = "Orange";
    private static final String YELLOW = "Yellow";
    private static final String PURPLE = "Purple";
    private static final String WHITE  = "White";
    private static final String BLACK = "Black";

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Random rng = new Random();

        // --- get student info ---
        System.out.print("Enter your name: ");
        String name = in.nextLine();

        System.out.print("Describe yourself: ");
        String about = in.nextLine();

        System.out.print("Due Date (MM/DD/YY): ");
        String due = in.nextLine();

        System.out.println();
        System.out.println(TITLE);

        int correct = 0;

        // --- play 11 rounds ---
        for (int round = 1; round <= TOTAL_ROUNDS; round++) {
            System.out.println("Round " + round);
            System.out.println("I am thinking of a color.");
            System.out.println("Is it Red, Green, Blue, Orange, Yellow, Purple, or White?");
            System.out.println("Enter your guess:");

            // pick a random color (0..6)
            int pick = rng.nextInt(7);
            String chosen;
            if (pick == 0)      chosen = RED;
            else if (pick == 1) chosen = GREEN;
            else if (pick == 2) chosen = BLUE;
            else if (pick == 3) chosen = ORANGE;
            else if (pick == 4) chosen = YELLOW;
            else if (pick == 5) chosen = PURPLE;
            else                chosen = WHITE;

            // read guess and validate until it is one of the allowed colors
            String guess = in.nextLine().trim();
            while (
                !(guess.equalsIgnoreCase(RED)    ||
                  guess.equalsIgnoreCase(GREEN)  ||
                  guess.equalsIgnoreCase(BLUE)   ||
                  guess.equalsIgnoreCase(ORANGE) ||
                  guess.equalsIgnoreCase(YELLOW) ||
                  guess.equalsIgnoreCase(PURPLE) ||
                  guess.equalsIgnoreCase(WHITE))
            ) {
                System.out.println("You entered incorrect color.");
                System.out.println("It must be: Red, Green, Blue, Orange, Yellow, Purple, or White.");
                System.out.println("Enter your guess again:");
                guess = in.nextLine().trim();
            }

            // compare (case-insensitive)
            if (guess.equalsIgnoreCase(chosen)) {
                correct++;
            }

            System.out.println("I was thinking of " + chosen + ".");
            System.out.println();
        }

        // --- summary ---
        System.out.println("Game Over");
        System.out.println("You guessed " + correct + " out of " + TOTAL_ROUNDS + " colors correctly.");
        System.out.println("Student Name: " + name);
        System.out.println("User Description: " + about);
        System.out.println("Due Date: " + due);

        in.close();
    }
}
